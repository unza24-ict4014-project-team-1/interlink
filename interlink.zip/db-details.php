<?php
   $dbHost = 'localhost';
   $dbUser = 'root';
   $dbName = 'interlink';
?>